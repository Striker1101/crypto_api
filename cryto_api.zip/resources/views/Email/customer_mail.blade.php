dear {{ $customer_details['name'] }} <br/> 
	  thank you for ordering with us <br/>
		Thank you<br/> our contact detail as of below<br/> kathmandu nepal<br/>
		email : {{ $customer_details['email'] }}